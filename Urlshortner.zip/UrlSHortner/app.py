# app.py (login/index route fixed)

from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User, URL
import validators

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
login_manager = LoginManager(app)
login_manager.login_view = 'index'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

with app.app_context():
    db.create_all()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        action = request.form.get('action')
        username = request.form.get('username')
        password = request.form.get('password')

        if action == 'login':
            user = User.query.filter_by(username=username).first()
            if user and check_password_hash(user.password, password):
                login_user(user)
                return redirect(url_for('dashboard'))
            flash('Invalid username or password', 'error')

        elif action == 'register':
            if User.query.filter_by(username=username).first():
                flash('Username already exists', 'error')
            else:
                hashed_pw = generate_password_hash(password)
                new_user = User(username=username, password=hashed_pw)
                db.session.add(new_user)
                db.session.commit()
                login_user(new_user)
                return redirect(url_for('dashboard'))

    return render_template('index.html')

@app.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    if request.method == 'POST':
        action = request.form.get('action')

        if action == 'create':
            original_url = request.form.get('original_url')
            if not validators.url(original_url):
                flash('Invalid URL', 'error')
            else:
                code = URL.generate_short_code()
                while URL.query.filter_by(short_code=code).first():
                    code = URL.generate_short_code()

                new_url = URL(
                    original_url=original_url,
                    short_code=code,
                    user_id=current_user.id
                )
                db.session.add(new_url)
                db.session.commit()
                flash('URL shortened!', 'success')

        elif action == 'update':
            url_id = request.form.get('url_id')
            new_url = request.form.get('new_url')
            url = URL.query.filter_by(id=url_id, user_id=current_user.id).first()
            if url and validators.url(new_url):
                url.original_url = new_url
                db.session.commit()
                flash('URL updated', 'success')
            else:
                flash('Invalid URL or not authorized', 'error')

        elif action == 'delete':
            url_id = request.form.get('url_id')
            url = URL.query.filter_by(id=url_id, user_id=current_user.id).first()
            if url:
                db.session.delete(url)
                db.session.commit()
                flash('URL deleted', 'success')
            else:
                flash('Not authorized', 'error')

    urls = URL.query.filter_by(user_id=current_user.id).all()
    return render_template('dashboard.html', urls=urls, base_url=request.host_url)

@app.route('/<short_code>')
def redirect_to_original(short_code):
    url = URL.query.filter_by(short_code=short_code).first()
    if url:
        url.clicks += 1
        db.session.commit()
        return redirect(url.original_url)
    return 'URL not found', 404

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)

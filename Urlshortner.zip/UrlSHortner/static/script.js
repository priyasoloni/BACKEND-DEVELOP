// static/main.js

document.addEventListener('DOMContentLoaded', () => {
    // Theme Logic
    const themes = {
        ocean: { primary: '#0ea5e9', secondary: '#0284c7', shapePositions: 'top-16 left-10 w-24 h-24, top-36 left-20 w-16 h-16, top-56 left-32 w-12 h-12' },
        sunset: { primary: '#f97316', secondary: '#ea580c', shapePositions: 'top-16 left-10 w-24 h-24, top-36 left-20 w-16 h-16, top-56 left-32 w-12 h-12' },
        forest: { primary: '#059669', secondary: '#047857', shapePositions: 'top-16 left-10 w-24 h-24, top-36 left-20 w-16 h-16, top-56 left-32 w-12 h-12' },
        royal: { primary: '#7c3aed', secondary: '#6d28d9', shapePositions: 'top-16 left-10 w-24 h-24, top-36 left-20 w-16 h-16, top-56 left-32 w-12 h-12' },
        cherry: { primary: '#dc2626', secondary: '#b91c1c', shapePositions: 'top-16 left-10 w-24 h-24, top-36 left-20 w-16 h-16, top-56 left-32 w-12 h-12' },
        golden: { primary: '#d97706', secondary: '#b45309', shapePositions: 'top-16 left-10 w-24 h-24, top-36 left-20 w-16 h-16, top-56 left-32 w-12 h-12' },
        midnight: { primary: '#1e40af', secondary: '#1d4ed8', shapePositions: 'top-16 left-10 w-24 h-24, top-36 left-20 w-16 h-16, top-56 left-32 w-12 h-12' },
        rose: { primary: '#e11d48', secondary: '#be185d', shapePositions: 'top-16 left-10 w-24 h-24, top-36 left-20 w-16 h-16, top-56 left-32 w-12 h-12' },
        emerald: { primary: '#10b981', secondary: '#059669', shapePositions: 'top-16 left-10 w-24 h-24, top-36 left-20 w-16 h-16, top-56 left-32 w-12 h-12' },
        cosmic: { primary: '#8b5cf6', secondary: '#7c3aed', shapePositions: 'top-16 left-10 w-24 h-24, top-36 left-20 w-16 h-16, top-56 left-32 w-12 h-12' },
    };

    const savedTheme = localStorage.getItem('linkcraft-theme') || 'ocean';
    applyTheme(savedTheme);

    const selector = document.getElementById('themeSelector');
    if (selector) {
        selector.value = savedTheme;
        selector.addEventListener('change', (e) => {
            applyTheme(e.target.value);
        });
    }

    function applyTheme(themeName) {
        const theme = themes[themeName];
        document.documentElement.style.setProperty('--primary', theme.primary);
        document.documentElement.style.setProperty('--secondary', theme.secondary);
        localStorage.setItem('linkcraft-theme', themeName);

        // Update shape positions
        const shapes = document.querySelectorAll('.floating-shapes .shape');
        if (shapes.length >= 3 && theme.shapePositions) {
            const positions = theme.shapePositions.split(',');
            shapes.forEach((shape, index) => {
                if (positions[index]) {
                    shape.className = `shape absolute bg-white rounded-full opacity-10 animate-float ${positions[index].trim()}`;
                }
            });
        }
    }

    // Form Toggle Logic
    window.showLogin = () => {
        document.getElementById('loginForm').classList.remove('hidden');
        document.getElementById('registerForm').classList.add('hidden');
    };

    window.showRegister = () => {
        document.getElementById('registerForm').classList.remove('hidden');
        document.getElementById('loginForm').classList.add('hidden');
    };

    // URL Edit Prompt
    window.editUrl = (id, currentUrl) => {
        const input = prompt("Enter new URL:", currentUrl);
        if (input && input !== currentUrl) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '/dashboard';

            form.innerHTML = `
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="url_id" value="${id}">
                <input type="hidden" name="new_url" value="${input}">
            `;

            document.body.appendChild(form);
            form.submit();
        }
    };

    // Copy to Clipboard
    window.copyToClipboard = (text) => {
        navigator.clipboard.writeText(text).then(() => {
            showToast('Copied to clipboard!', 'success');
        });
    };

    // Toast Notification
    window.showToast = (message, type) => {
        let toast = document.getElementById('toast');
        let icon = document.getElementById('toastIcon');
        let msg = document.getElementById('toastMessage');

        if (!toast) return;

        icon.className = type === 'success' ? 'fas fa-check-circle text-green-400' : 'fas fa-exclamation-circle text-red-400';
        msg.textContent = message;

        toast.classList.remove('hidden');
        setTimeout(() => {
            toast.classList.add('hidden');
        }, 3000);
    };
});

// Theme selector functionality
const selector = document.getElementById('themeSelector');  
if (selector) {

console.log("Theme selector found and working!");
}